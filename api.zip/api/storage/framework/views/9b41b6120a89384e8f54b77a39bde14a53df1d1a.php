<?php echo e($slot); ?>

<?php /**PATH D:\virza\htdocs\laravelNuxt\api\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>